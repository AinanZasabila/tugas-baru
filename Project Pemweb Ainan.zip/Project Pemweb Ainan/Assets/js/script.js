let typed = new Typed(".teks", {
  strings: ["Sedang Belajar JavaScript", "Developer Pemula"],
  typeSpeed: 60,
  backSpeed: 60,
  backDelay: 1000,
  loop: true,
});
